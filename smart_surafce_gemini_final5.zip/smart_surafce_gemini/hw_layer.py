# hw_layer.py

import time
import statistics
from gpiozero import Device, Buzzer, Button, DistanceSensor
from gpiozero.pins.pigpio import PiGPIOFactory

# I2C libraries
import board
import busio
import adafruit_tcs34725
import adafruit_mlx_90614

# Luma OLED libraries
from luma.core.interface.serial import i2c
from luma.core.render import canvas
from luma.oled.device import ssd1306

# --- ROBUSTNESS: Clean up any pins left open by a previous run ---
def cleanup_gpio_pins():
    """
    Closes the default pin factory, releasing all GPIO pins.
    This is crucial for preventing 'GPIO busy' errors when the Flask
    auto-reloader restarts the script.
    """
    try:
        # Set the pin factory for best performance on Pi 5 (optional but recommended)
        # Device.pin_factory = PiGPIOFactory()
        
        if Device.pin_factory:
            Device.pin_factory.close()
            print("INFO: Cleaned up previously used GPIO pins.")
    except Exception as e:
        # This might fail if no factory was running, which is fine.
        print(f"Notice: Could not perform GPIO cleanup. This is often okay. Error: {e}")

# --- Call the cleanup function at the very start of the script ---
cleanup_gpio_pins()

# --- HARDWARE PIN CONFIGURATION ---
# Centralize all GPIO pin numbers here
ULTRASONIC_TRIG_PIN = 23
ULTRASONIC_ECHO_PIN = 24
BUZZER_PIN = 18
BUTTON_PIN = 17 # (Currently unused in the app, but defined for completeness)

# --- HARDWARE INITIALIZATION (Objects are created only ONCE) ---

try:
    i2c_bus = busio.I2C(board.SCL, board.SDA)
except Exception as e:
    print(f"FATAL: I2C bus could not be initialized. Error: {e}")
    i2c_bus = None

mlx_sensor = adafruit_mlx90614.MLX90614(i2c_bus) if i2c_bus else None
tcs_sensor = adafruit_tcs34725.TCS34725(i2c_bus) if i2c_bus else None

try:
    oled_serial = i2c(port=1, address=0x3C)
    oled_device = ssd1306(oled_serial)
except Exception as e:
    print(f"Warning: Could not initialize OLED Display. Error: {e}")
    oled_device = None

# Initialize GPIO devices once
try:
    distance_sensor_obj = DistanceSensor(echo=ULTRASONIC_ECHO_PIN, trigger=ULTRASONIC_TRIG_PIN)
    buzzer_obj = Buzzer(BUZZER_PIN)
    button_obj = Button(BUTTON_PIN, pull_up=True)
except Exception as e:
    print(f"Warning: A GPIO device could not be initialized. Error: {e}")
    distance_sensor_obj = None
    buzzer_obj = None
    button_obj = None

# ... (Helper functions like get_color_name are unchanged) ...
def get_color_name(rgb):
    r, g, b = rgb
    if r > 200 and g > 200 and b > 200: return "White"
    if r < 30 and g < 30 and b < 30: return "Black"
    if r > g and r > b: return "Red"
    if g > r and g > b: return "Green"
    if b > r and b > g: return "Blue"
    if r > 100 and g > 100 and b < 50: return "Yellow"
    return "Unknown"

# --- CORE HARDWARE FUNCTIONS (Now use the pre-initialized objects) ---

def read_temperature():
    if mlx_sensor:
        try: return {"ambient": round(mlx_sensor.ambient_temperature, 1), "object": round(mlx_sensor.object_temperature, 1)}
        except (OSError, IOError): return {"ambient": 0, "object": 0}
    return {"ambient": 25.0, "object": 25.0}

def read_color():
    if tcs_sensor:
        try: return {"color_name": get_color_name(tcs_sensor.color_rgb_bytes)}
        except Exception: return {"color_name": "Error"}
    return {"color_name": "N/A"}

def buzzer_beep(duration):
    """Uses the pre-initialized buzzer object."""
    if buzzer_obj:
        buzzer_obj.beep(on_time=duration, n=1)

def read_button():
    """Uses the pre-initialized button object."""
    if button_obj:
        return not button_obj.is_pressed
    return True # Default to not pressed

def measure_distance(samples=10):
    """Uses the pre-initialized distance sensor object."""
    if not distance_sensor_obj:
        print("Distance sensor is not available.")
        return 0, 0
    readings = [distance_sensor_obj.distance * 100 for _ in range(samples)]
    valid_readings = [r for r in readings if 2 < r < 400]
    if not valid_readings: return 0, 0
    avg = round(statistics.mean(valid_readings), 2)
    std_dev = round(statistics.stdev(valid_readings) if len(valid_readings) > 1 else 0, 2)
    return avg, std_dev

# ... (analyze_absorption and update_physical_oled are unchanged) ...
def analyze_absorption(sigma):
    if sigma > 1.2: return "High"
    elif sigma > 0.5: return "Medium"
    else: return "Low"

def update_physical_oled(distance, shape, material):
    if oled_device:
        try:
            with canvas(oled_device) as draw:
                draw.text((0, 0), f"Dist: {distance}", fill="white")
                draw.text((0, 12), f"Shape: {shape}", fill="white")
                draw.text((0, 24), f"Mat: {material}", fill="white")
        except Exception as e: print(f"Error writing to OLED: {e}")
    else:
        print(f"--- OLED Sim ---\nDist: {distance}\nShape: {shape}\nMat: {material}\n----------------")