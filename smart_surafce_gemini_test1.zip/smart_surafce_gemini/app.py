# app.py

from flask import Flask, jsonify, render_template, request
from hw_layer import (measure_distance, analyze_absorption, read_color,
                      read_temperature, buzzer_beep, read_button)
import threading
import statistics # Used for standard deviation

app = Flask(__name__)

# GPIO pin config (for simulation context)
TRIG = 23
ECHO = 24
BUZZER = 18
BUTTON = 17

# --- API Endpoints ---

@app.route('/')
def index():
    """Serves the main dashboard page."""
    return render_template('index.html')

@app.route('/status')
def get_status():
    """Provides the status of all sensors."""
    temps = read_temperature()
    status = {
        "ultrasonic": True, # Hardcoded for reliability
        "color_sensor": True,
        "temperature_sensor": True,
        "button": read_button(BUTTON),
        "oled_display": True,
        "buzzer": True,
        "ambient_temp": temps["ambient"],
        "object_temp": temps["object"],
    }
    return jsonify(status)

@app.route('/measure_distance')
def measure_distance_route():
    """Endpoint for a single distance measurement."""
    avg, sigma = measure_distance(TRIG, ECHO, samples=10)
    temps = read_temperature()
    # Speed of sound c ≈ 331.3 + 0.606 * T_ambient
    ultrasonic_speed = round(331.3 + 0.606 * temps["ambient"], 1)

    return jsonify({
        "distance": avg,
        "sigma": sigma,
        "ambient_temp": temps["ambient"],
        "object_temp": temps["object"],
        "ultrasonic_speed": ultrasonic_speed
    })

@app.route('/scan', methods=['POST'])
def scan_route():
    """
    Generalized endpoint for taking multiple readings for either 
    shape detection or material testing.
    """
    data = request.get_json()
    repetitions = data.get('repetitions', 15)
    
    # Ensure repetitions is a reasonable number to prevent server abuse
    repetitions = min(int(repetitions), 100)
    
    measurements = []
    distances = []

    for i in range(repetitions):
        avg, _ = measure_distance(TRIG, ECHO, samples=5) # Fewer samples per reading for faster scans
        measurements.append({"reading": i + 1, "distance": avg})
        distances.append(avg)
        
    # Calculate statistics
    overall_sigma = round(statistics.stdev(distances) if len(distances) > 1 else 0, 2)
    absorption = analyze_absorption(overall_sigma)
    
    # Get latest color and temp readings
    color = read_color()
    temps = read_temperature()
    ultrasonic_speed = round(331.3 + 0.606 * temps["ambient"], 1)

    return jsonify({
        "scan_data": measurements,
        "statistics": {
            "average": round(statistics.mean(distances), 2),
            "sigma": overall_sigma,
            "min": min(distances),
            "max": max(distances)
        },
        "absorption_analysis": absorption,
        "color": color["color_name"],
        "ambient_temp": temps["ambient"],
        "object_temp": temps["object"],
        "ultrasonic_speed": ultrasonic_speed
    })

@app.route('/buzzer', methods=['POST'])
def buzz_route():
    """Endpoint to trigger the buzzer."""
    threading.Thread(target=buzzer_beep, args=(BUZZER, 0.05)).start() # Shorter beep
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)