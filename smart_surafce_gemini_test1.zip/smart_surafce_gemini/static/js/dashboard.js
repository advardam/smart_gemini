// static/js/dashboard.js

document.addEventListener('DOMContentLoaded', function() {
    // --- Global State ---
    let liveModeInterval = null;

    // --- DOM Element References ---
    const radar = document.getElementById('radar');
    
    const dataFields = {
        distance: document.getElementById('data-distance'),
        color: document.getElementById('data-color'),
        ambient_temp: document.getElementById('data-ambient-temp'),
        object_temp: document.getElementById('data-object-temp'),
        ultrasonic_speed: document.getElementById('data-ultrasonic-speed'),
        absorption: document.getElementById('data-absorption'),
        colorSwatch: document.getElementById('color-swatch')
    };

    const statFields = {
        avg: document.getElementById('stat-avg'),
        sigma: document.getElementById('stat-sigma'),
        minmax: document.getElementById('stat-minmax')
    };

    const buttons = {
        measureDistance: document.getElementById('btn-measure-distance'),
        detectShape: document.getElementById('btn-detect-shape'),
        testMaterial: document.getElementById('btn-test-material')
    };
    
    const allButtons = Object.values(buttons);
    
    const inputs = {
        shapeReadings: document.getElementById('shape-readings'),
        liveModeToggle: document.getElementById('live-mode')
    };
    
    const statusLights = {
        ultrasonic: document.getElementById('status-ultrasonic'),
        color_sensor: document.getElementById('status-color_sensor'),
        temperature_sensor: document.getElementById('status-temperature_sensor'),
        button: document.getElementById('status-button'),
        oled_display: document.getElementById('status-oled_display'),
        buzzer: document.getElementById('status-buzzer')
    };
    
    // --- Chart.js Initialization ---
    const ctx = document.getElementById('distanceChart').getContext('2d');
    const distanceChart = new Chart(ctx, {
        type: 'line',
        data: { labels: [], datasets: [{
            label: 'Distance (cm)', data: [],
            borderColor: 'rgba(243, 196, 62, 1)',
            backgroundColor: 'rgba(243, 196, 62, 0.2)',
            borderWidth: 2, tension: 0.1, fill: true
        }]},
        options: {
            scales: {
                y: { beginAtZero: true, title: { display: true, text: 'Distance (cm)', color: '#fff' }, ticks: { color: '#fff' } },
                x: { title: { display: true, text: 'Reading #', color: '#fff' }, ticks: { color: '#fff' } }
            },
            plugins: { legend: { display: false } }
        }
    });

    // --- UI Control Functions ---

    function setButtonsLoading(isLoading) {
        allButtons.forEach(btn => {
            btn.disabled = isLoading;
            if (isLoading) {
                btn.dataset.originalText = btn.textContent;
                btn.textContent = 'Measuring...';
            } else {
                btn.textContent = btn.dataset.originalText || btn.textContent;
            }
        });
    }

    function triggerRadarPing() {
        radar.classList.add('ping');
        setTimeout(() => radar.classList.remove('ping'), 300);
    }

    // --- API & Data Handling Functions ---

    async function fetchData(url, options = {}) {
        try {
            const response = await fetch(url, options);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return await response.json();
        } catch (error) {
            console.error("Failed to fetch data:", error);
            return null;
        }
    }

    function triggerBuzzer() {
        fetchData('/buzzer', { method: 'POST' });
    }
    
    function updateStatusLights(status) {
        for (const key in statusLights) {
            const light = statusLights[key];
            if (status[key]) {
                light.className = 'status-light ok';
            } else {
                light.className = 'status-light fail';
            }
        }
    }

    function updateUIData(data) {
        // Live Data
        if (data.distance) dataFields.distance.textContent = `${data.distance} cm`;
        if (data.color) {
            dataFields.color.textContent = data.color;
            dataFields.colorSwatch.style.backgroundColor = data.color.toLowerCase();
        }
        if (data.ambient_temp) dataFields.ambient_temp.textContent = `${data.ambient_temp} °C`;
        if (data.object_temp) dataFields.object_temp.textContent = `${data.object_temp} °C`;
        if (data.ultrasonic_speed) dataFields.ultrasonic_speed.textContent = `${data.ultrasonic_speed} m/s`;
        
        // Analysis Data
        if (data.absorption_analysis) {
            const materialType = data.absorption_analysis === "High" ? "Absorbing" : "Reflective";
            dataFields.absorption.textContent = materialType;
        }
        if (data.statistics) {
            statFields.avg.textContent = `${data.statistics.average} cm`;
            statFields.sigma.textContent = `${data.statistics.sigma}`;
            statFields.minmax.textContent = `${data.statistics.min} / ${data.statistics.max} cm`;
        }
    }

    function updateChart(scanData) {
        distanceChart.data.labels = scanData.map(d => d.reading);
        distanceChart.data.datasets[0].data = scanData.map(d => d.distance);
        distanceChart.update();
    }

    // --- Main Action Functions ---

    async function handleSingleMeasurement() {
        setButtonsLoading(true);
        triggerBuzzer();
        const data = await fetchData('/measure_distance');
        if (data) {
            // Adapt single measurement to the new UI structure
            updateUIData({
                distance: data.distance,
                ambient_temp: data.ambient_temp,
                object_temp: data.object_temp,
                ultrasonic_speed: data.ultrasonic_speed,
                absorption_analysis: analyzeAbsorption(data.sigma), // Local analysis for single point
                statistics: { average: data.distance, sigma: data.sigma, min: data.distance, max: data.distance }
            });
            triggerRadarPing();
        }
        setButtonsLoading(false);
    }
    
    function analyzeAbsorption(sigma) {
        if (sigma > 1.0) return "High";
        if (sigma > 0.5) return "Medium";
        return "Low";
    }

    async function handleScan(repetitions) {
        setButtonsLoading(true);
        triggerBuzzer();
        const data = await fetchData('/scan', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ repetitions })
        });
        if (data) {
            updateUIData({
                distance: data.statistics.average, // Show the average distance in the main display
                color: data.color,
                ambient_temp: data.ambient_temp,
                object_temp: data.object_temp,
                ultrasonic_speed: data.ultrasonic_speed,
                absorption_analysis: data.absorption_analysis,
                statistics: data.statistics
            });
            updateChart(data.scan_data);
            triggerRadarPing();
        }
        setButtonsLoading(false);
    }

    // --- Event Listeners ---

    buttons.measureDistance.addEventListener('click', handleSingleMeasurement);
    buttons.detectShape.addEventListener('click', () => {
        const reps = parseInt(inputs.shapeReadings.value, 10);
        handleScan(reps);
    });
    buttons.testMaterial.addEventListener('click', () => {
        handleScan(20); // Hardcoded to 20 readings as requested
    });

    inputs.liveModeToggle.addEventListener('change', (event) => {
        if (event.target.checked) {
            handleSingleMeasurement(); // Run once immediately
            liveModeInterval = setInterval(handleSingleMeasurement, 3000); // Then every 3 seconds
        } else {
            clearInterval(liveModeInterval);
        }
    });

    // --- Periodic Status Update ---
    
    async function refreshStatus() {
        const status = await fetchData('/status');
        if (status) updateStatusLights(status);
    }

    setInterval(refreshStatus, 5000);
    refreshStatus();
});