# hw_layer.py

import time
import statistics
import RPi.GPIO as GPIO

# I2C libraries for sensors and display
import board
import busio
from smbus2 import SMBus

# Specific hardware libraries
from mlx90614 import MLX90614
import adafruit_tcs34725
from luma.core.interface.serial import i2c
from luma.core.render import canvas
from luma.oled.device import ssd1306

# --- ONE-TIME HARDWARE SETUP ---

# Suppress GPIO warnings
GPIO.setwarnings(False)
# Use Broadcom pin numbering
GPIO.setmode(GPIO.BCM)

# Initialize I2C bus
try:
    i2c_bus = busio.I2C(board.SCL, board.SDA)
    smbus = SMBus(1) # Port 1
except Exception as e:
    print(f"FATAL: Could not initialize I2C bus. Check connections. Error: {e}")
    i2c_bus = None
    smbus = None

# --- SENSOR INITIALIZATION ---

# Initialize Temperature Sensor (MLX90614)
try:
    mlx_sensor = MLX90614(smbus, address=0x5A)
except Exception as e:
    print(f"Warning: Could not initialize Temperature Sensor. Using default values. Error: {e}")
    mlx_sensor = None

# Initialize Color Sensor (TCS34725)
try:
    tcs_sensor = adafruit_tcs34725.TCS34725(i2c_bus)
except Exception as e:
    print(f"Warning: Could not initialize Color Sensor. Using default values. Error: {e}")
    tcs_sensor = None
    
# Initialize OLED Display (SSD1306)
try:
    oled_serial = i2c(port=1, address=0x3C)
    oled_device = ssd1306(oled_serial)
except Exception as e:
    print(f"Warning: Could not initialize OLED Display. Printing to console instead. Error: {e}")
    oled_device = None

# --- HELPER FUNCTIONS ---

def get_color_name(rgb):
    """Converts an RGB tuple to a simple color name."""
    r, g, b = rgb
    # Simple thresholds for black/white
    if r > 200 and g > 200 and b > 200:
        return "White"
    if r < 30 and g < 30 and b < 30:
        return "Black"
        
    # Find the dominant color
    if r > g and r > b:
        return "Red"
    if g > r and g > b:
        return "Green"
    if b > r and b > g:
        return "Blue"
    # Basic check for yellow
    if r > 100 and g > 100 and b < 50:
        return "Yellow"
        
    return "Unknown" # Default case

# --- CORE HARDWARE FUNCTIONS ---

def read_temperature():
    """Reads real ambient and object temperatures from the MLX90614 sensor."""
    if mlx_sensor:
        try:
            ambient = round(mlx_sensor.get_ambient(), 1)
            obj_temp = round(mlx_sensor.get_object_1(), 1)
            return {"ambient": ambient, "object": obj_temp}
        except (OSError, IOError) as e:
            print(f"Error reading temperature sensor: {e}")
            return {"ambient": 0, "object": 0} # Return default on error
    else:
        # Return dummy data if sensor failed to initialize
        return {"ambient": 25.0, "object": 25.0}

def read_color():
    """Reads the color from the TCS34725 sensor and returns its name."""
    if tcs_sensor:
        try:
            color_name = get_color_name(tcs_sensor.color_rgb_bytes)
            return {"color_name": color_name}
        except Exception as e:
            print(f"Error reading color sensor: {e}")
            return {"color_name": "Error"}
    else:
        return {"color_name": "N/A"}

def buzzer_beep(pin, duration):
    """Creates a beep on a buzzer connected to a specific GPIO pin."""
    GPIO.setup(pin, GPIO.OUT)
    GPIO.output(pin, GPIO.HIGH)
    time.sleep(duration)
    GPIO.output(pin, GPIO.LOW)

def read_button(pin):
    """Reads the state of a button (assumes pull-up resistor)."""
    # Setup pin with an internal pull-up resistor
    GPIO.setup(pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
    # Returns True if not pressed, False if pressed (button connects to GND)
    return GPIO.input(pin)

def measure_distance(trig_pin, echo_pin, samples=10):
    """
    Measures distance using an HC-SR04 ultrasonic sensor.
    Takes multiple samples to return an average and standard deviation.
    """
    GPIO.setup(trig_pin, GPIO.OUT)
    GPIO.setup(echo_pin, GPIO.IN)
    
    readings = []
    for _ in range(samples):
        # Send a 10µs pulse to trigger the sensor
        GPIO.output(trig_pin, True)
        time.sleep(0.00001)
        GPIO.output(trig_pin, False)

        pulse_start_time = time.time()
        pulse_end_time = time.time()
        
        timeout = pulse_start_time + 0.1 # 100ms timeout

        # Record the time the echo pin goes HIGH
        while GPIO.input(echo_pin) == 0 and pulse_start_time < timeout:
            pulse_start_time = time.time()
            
        # Record the time the echo pin goes LOW
        while GPIO.input(echo_pin) == 1 and pulse_end_time < timeout:
            pulse_end_time = time.time()
            
        pulse_duration = pulse_end_time - pulse_start_time
        
        # Speed of sound is ~34300 cm/s. Distance is (duration * speed) / 2 (for out and back)
        distance = round(pulse_duration * 17150, 2)
        
        if 2 < distance < 400: # Filter out unrealistic readings
            readings.append(distance)
        
        time.sleep(0.05) # Wait a bit between readings

    if not readings:
        return 0, 0 # Return 0 if no valid readings were taken
        
    avg_distance = round(statistics.mean(readings), 2)
    std_dev = round(statistics.stdev(readings) if len(readings) > 1 else 0, 2)
    
    return avg_distance, std_dev
    
def analyze_absorption(sigma):
    """
    Classifies material absorption based on standard deviation.
    CALIBRATE THESE VALUES based on your testing.
    """
    if sigma > 1.2: return "High"   # Likely soft/absorbing material
    elif sigma > 0.5: return "Medium"
    else: return "Low"      # Likely hard/reflective material


def update_physical_oled(distance, shape, material):
    """Sends the final analysis results to the physical SSD1306 OLED display."""
    if oled_device:
        try:
            with canvas(oled_device) as draw:
                # Use a small, readable font if available, otherwise default
                # from PIL import ImageFont
                # font = ImageFont.truetype("your_font.ttf", 10)
                draw.text((0, 0), f"Dist: {distance}", fill="white")
                draw.text((0, 12), f"Shape: {shape}", fill="white")
                draw.text((0, 24), f"Mat: {material}", fill="white")
        except Exception as e:
            print(f"Error writing to OLED: {e}")
    else:
        # Fallback to console if OLED failed to initialize
        print("--- Sending to Physical OLED (simulated) ---")
        print(f"  Line 1: Dist: {distance}")
        print(f"  Line 2: Shape: {shape}")
        print(f"  Line 3: Mat: {material}")
        print("---------------------------------")