// static/js/dashboard.js

document.addEventListener('DOMContentLoaded', function() {
    // --- DOM Element References ---
    const errorBar = document.getElementById('error-bar');
    const errorMessage = document.getElementById('error-message');
    const radar = document.getElementById('radar');
    const radarText = document.getElementById('radar-text-overlay');

    const oled = {
        line1: document.getElementById('oled-line-1'),
        line2: document.getElementById('oled-line-2'),
        line3: document.getElementById('oled-line-3')
    };

    const analysisFields = {
        shape: document.getElementById('analysis-shape'),
        material: document.getElementById('analysis-material'),
        avg: document.getElementById('stat-avg'),
        sigma: document.getElementById('stat-sigma')
    };

    const buttons = {
        detectShape: document.getElementById('btn-detect-shape'),
        testMaterial: document.getElementById('btn-test-material')
    };
    
    const allButtons = Object.values(buttons);
    
    const inputs = {
        shapeReadings: document.getElementById('shape-readings')
    };
    
    const statusLights = {
        ultrasonic: document.getElementById('status-ultrasonic'),
        color_sensor: document.getElementById('status-color_sensor'),
        temperature_sensor: document.getElementById('status-temperature_sensor'),
        oled_display: document.getElementById('status-oled_display'),
        buzzer: document.getElementById('status-buzzer')
    };
    
    // --- Chart.js Initialization ---
    // ... (Chart.js code remains the same as before)
    const ctx = document.getElementById('distanceChart').getContext('2d');
    const distanceChart = new Chart(ctx, { /* ... same config ... */ });


    // --- UI Control Functions ---

    function setButtonsLoading(isLoading) {
        allButtons.forEach(btn => {
            btn.disabled = isLoading;
            btn.textContent = isLoading ? 'Scanning...' : btn.dataset.originalText;
        });
        inputs.shapeReadings.disabled = isLoading;
    }
    
    function showError(message) {
        errorMessage.textContent = message;
        errorBar.classList.remove('hidden');
        statusLights.ultrasonic.className = 'status-light fail';
    }

    function hideError() {
        errorBar.classList.add('hidden');
    }

    function showRadarText(text) {
        radarText.textContent = text;
        radarText.classList.add('visible');
        setTimeout(() => {
            radarText.classList.remove('visible');
        }, 2500); // Hide after 2.5 seconds
    }
    
    function triggerBuzzer() {
        fetch('/buzzer', { method: 'POST' });
    }

    // --- API & Data Handling ---

    async function fetchData(url, options = {}) {
        hideError(); // Hide any previous errors
        setButtonsLoading(true);
        triggerBuzzer();

        try {
            const response = await fetch(url, options);
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || `Server responded with status ${response.status}`);
            }
            return await response.json();
        } catch (error) {
            showError(error.message);
            return null;
        } finally {
            setButtonsLoading(false);
        }
    }
    
    function updateOledDisplay(data) {
        oled.line1.textContent = `Dist: ${data.avg_dist || '--'} cm`;
        oled.line2.textContent = `Shape: ${data.shape || 'N/A'}`;
        oled.line3.textContent = `Mat: ${data.material || 'N/A'}`;
    }

    function updateDashboard(data) {
        // Update Analysis Card
        analysisFields.shape.textContent = data.shape_analysis;
        analysisFields.shape.classList.add('alert');
        
        const materialType = data.absorption_analysis === "High" ? "Absorbing" : "Reflective";
        analysisFields.material.textContent = materialType;
        analysisFields.material.classList.add('alert');
        
        analysisFields.avg.textContent = `${data.statistics.average} cm`;
        analysisFields.sigma.textContent = `${data.statistics.sigma}`;

        setTimeout(() => {
            analysisFields.shape.classList.remove('alert');
            analysisFields.material.classList.remove('alert');
        }, 1000);

        // Update Chart
        distanceChart.data.labels = data.scan_data.map(d => d.reading);
        distanceChart.data.datasets[0].data = data.scan_data.map(d => d.distance);
        distanceChart.update();
        
        // Update OLED
        updateOledDisplay({
            avg_dist: data.statistics.average,
            shape: data.shape_analysis,
            material: materialType
        });

        // Show radar text
        showRadarText(data.shape_analysis + " Detected");

        // Update status lights to OK
        Object.values(statusLights).forEach(light => light.className = 'status-light ok');
    }

    // --- Main Action Functions ---

    async function handleScan(repetitions) {
        const data = await fetchData('/scan', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ repetitions })
        });
        if (data) {
            updateDashboard(data);
        }
    }

    // --- Event Listeners ---
    buttons.detectShape.addEventListener('click', () => {
        const reps = parseInt(inputs.shapeReadings.value, 10);
        handleScan(reps);
    });

    buttons.testMaterial.addEventListener('click', () => {
        handleScan(20); // Test material always uses 20 readings
    });

    // --- Initial Setup ---
    function initialize() {
        allButtons.forEach(btn => { btn.dataset.originalText = btn.textContent; });
        Object.values(statusLights).forEach(light => light.className = 'status-light ok');
        updateOledDisplay({}); // Clear OLED
    }

    initialize();
});