# app.py

from flask import Flask, jsonify, render_template, request
from hw_layer import (measure_distance, analyze_absorption, read_color,
                      read_temperature, buzzer_beep, read_button)
import threading
import statistics
import random # For simulating errors

app = Flask(__name__)

# --- Analysis Logic ---
def analyze_shape(sigma):
    """Classifies a shape based on the standard deviation of distance readings."""
    if sigma < 0.5:
        return "Flat Surface"
    elif sigma < 2.5:
        return "Slightly Curved"
    else:
        return "Curved / Irregular"

# --- API Endpoints ---

@app.route('/')
def index():
    """Serves the main dashboard page."""
    return render_template('index.html')

@app.route('/status')
def get_status():
    """Provides the status of all sensors."""
    # This endpoint is kept simple and reliable
    return jsonify({"status": "ok"})

@app.route('/scan', methods=['POST'])
def scan_route():
    """
    Generalized endpoint for taking multiple readings for either 
    shape detection or material testing.
    """
    # --- Simulate potential sensor failure ---
    if random.random() < 0.1: # 10% chance of failure
        return jsonify({"error": "Ultrasonic sensor timeout"}), 500

    data = request.get_json()
    repetitions = data.get('repetitions', 15)
    repetitions = min(int(repetitions), 100)
    
    measurements = []
    distances = []

    for i in range(repetitions):
        avg, _ = measure_distance(TRIG, ECHO, samples=5)
        measurements.append({"reading": i + 1, "distance": avg})
        distances.append(avg)
        
    # Calculate statistics
    if len(distances) > 1:
        overall_sigma = round(statistics.stdev(distances), 2)
        avg_distance = round(statistics.mean(distances), 2)
    else:
        overall_sigma = 0
        avg_distance = distances[0] if distances else 0

    # Get analysis results
    absorption_analysis = analyze_absorption(overall_sigma)
    shape_analysis = analyze_shape(overall_sigma)
    
    # Get latest environmental readings
    color = read_color()
    temps = read_temperature()
    ultrasonic_speed = round(331.3 + 0.606 * temps["ambient"], 1)

    return jsonify({
        "scan_data": measurements,
        "statistics": {
            "average": avg_distance,
            "sigma": overall_sigma,
            "min": min(distances),
            "max": max(distances)
        },
        "absorption_analysis": absorption_analysis,
        "shape_analysis": shape_analysis,
        "color": color["color_name"],
        "ambient_temp": temps["ambient"],
        "object_temp": temps["object"],
        "ultrasonic_speed": ultrasonic_speed
    })

@app.route('/buzzer', methods=['POST'])
def buzz_route():
    threading.Thread(target=buzzer_beep, args=(18, 0.05)).start()
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)