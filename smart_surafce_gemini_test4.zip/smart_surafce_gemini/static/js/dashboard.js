// static/js/dashboard.js

document.addEventListener('DOMContentLoaded', function() {
    // --- DOM Elements ---
    const radar = document.getElementById('radar');
    const radarText = document.getElementById('radar-text-overlay');
    const buttons = {
        checkDistance: document.getElementById('btn-check-distance'),
        checkShape: document.getElementById('btn-check-shape'),
        checkMaterial: document.getElementById('btn-check-material'),
    };
    const allButtons = Object.values(buttons);
    const analysisFields = {
        shape: document.getElementById('analysis-shape'),
        material: document.getElementById('analysis-material'),
        avg: document.getElementById('stat-avg'),
        sigma: document.getElementById('stat-sigma'),
    };
    const modal = document.getElementById('conclusion-modal');
    const conclusionBtn = document.getElementById('btn-show-conclusion');
    const closeModalBtn = document.querySelector('.modal-close-button');

    // Chart.js initialization
    const ctx = document.getElementById('distanceChart').getContext('2d');
    const distanceChart = new Chart(ctx, { /* ... same config ... */ });

    // --- UI Control ---

    function setScanningState(isScanning, message = 'Scanning...') {
        allButtons.forEach(btn => { btn.disabled = isScanning; });

        if (isScanning) {
            radar.classList.add('is-scanning');
            radarText.textContent = message;
            radarText.classList.add('visible');
        } else {
            radar.classList.remove('is-scanning');
            // Don't hide the text yet, the result will overwrite it
        }
    }

    function triggerRadarPing() {
        radar.classList.add('is-pinging');
        // Remove the class after the animation is done to allow re-triggering
        setTimeout(() => radar.classList.remove('is-pinging'), 700);
    }

    // --- API & Data Handling ---

    async function performScan(endpoint, body) {
        setScanningState(true);
        try {
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });
            if (!response.ok) {
                // ... (existing error handling)
                setScanningState(false);
                return null;
            }
            return await response.json();
        } catch (error) {
            // ... (existing error handling)
            setScanningState(false);
            return null;
        }
    }

    function updateDashboard(data) {
        triggerRadarPing();

        // Delay result display slightly to let the ping animation start
        setTimeout(() => {
            // Update Analysis Card
            analysisFields.avg.textContent = `${data.statistics.average} cm`;
            analysisFields.sigma.textContent = data.statistics.sigma;
            analysisFields.shape.textContent = data.shape_analysis;
            analysisFields.material.textContent = data.material_analysis;

            // Show result on radar
            radarText.textContent = `${data.shape_analysis} Detected`;
            radarText.classList.add('visible'); // Ensure it stays visible
            
            // Hide radar text after a delay
            setTimeout(() => radarText.classList.remove('visible'), 2500);

            // Update chart
            distanceChart.data.labels = data.scan_data.map(d => d.reading);
            distanceChart.data.datasets[0].data = data.scan_data.map(d => d.distance);
            distanceChart.update();

            setScanningState(false);
        }, 300); // 300ms delay
    }

    // --- Event Listeners ---
    buttons.checkDistance.addEventListener('click', async () => {
        const data = await performScan('/measure_distance_single', {});
        if (data) {
            triggerRadarPing();
            setTimeout(() => {
                analysisFields.avg.textContent = `${data.distance} cm`;
                analysisFields.sigma.textContent = data.sigma;
                analysisFields.shape.textContent = "N/A";
                analysisFields.material.textContent = "N/A";

                radarText.textContent = `Distance: ${data.distance} cm`;
                setTimeout(() => radarText.classList.remove('visible'), 2500);

                setScanningState(false);
            }, 300);
        }
    });

    buttons.checkShape.addEventListener('click', async () => {
        const data = await performScan('/scan', { repetitions: 20 });
        if (data) updateDashboard(data);
    });

    buttons.checkMaterial.addEventListener('click', async () => {
        const data = await performScan('/scan', { repetitions: 20 });
        if (data) updateDashboard(data);
    });

    // Modal listeners
    conclusionBtn.addEventListener('click', () => modal.classList.remove('hidden'));
    closeModalBtn.addEventListener('click', () => modal.classList.add('hidden'));
    modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.add('hidden');
    });
});