// static/js/dashboard.js

document.addEventListener('DOMContentLoaded', function() {
    // --- DOM Element References ---
    const statusLights = {
        ultrasonic: document.getElementById('status-ultrasonic'),
        color_sensor: document.getElementById('status-color_sensor'),
        temperature_sensor: document.getElementById('status-temperature_sensor'),
        button: document.getElementById('status-button'),
        oled_display: document.getElementById('status-oled_display'),
        buzzer: document.getElementById('status-buzzer')
    };
    
    const dataFields = {
        distance1: document.getElementById('data-distance1'),
        distance2: document.getElementById('data-distance2'),
        color: document.getElementById('data-color'),
        ambient_temp1: document.getElementById('data-ambient-temp1'),
        ambient_temp2: document.getElementById('data-ambient-temp2'),
        object_temp: document.getElementById('data-object-temp'),
        ultrasonic_speed1: document.getElementById('data-ultrasonic-speed1'),
        ultrasonic_speed2: document.getElementById('data-ultrasonic-speed2'),
        absorption: document.getElementById('data-absorption')
    };

    const buttons = {
        measureDistance: document.getElementById('btn-measure-distance'),
        detectShape: document.getElementById('btn-detect-shape'),
        testMaterial: document.getElementById('btn-test-material')
    };

    // --- Chart.js Initialization ---
    const ctx = document.getElementById('distanceChart').getContext('2d');
    const distanceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Distance (cm)',
                data: [],
                borderColor: 'rgba(243, 196, 62, 1)',
                backgroundColor: 'rgba(243, 196, 62, 0.2)',
                borderWidth: 2,
                tension: 0.1,
                fill: true
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    title: { display: true, text: 'Distance (cm)', color: '#fff' },
                    ticks: { color: '#fff' }
                },
                x: {
                    title: { display: true, text: 'Reading #', color: '#fff' },
                    ticks: { color: '#fff' }
                }
            },
            plugins: {
                legend: { display: false }
            }
        }
    });

    // --- API Call Functions ---

    async function fetchData(url, options = {}) {
        try {
            const response = await fetch(url, options);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return await response.json();
        } catch (error) {
            console.error("Failed to fetch data:", error);
            return null;
        }
    }

    async function triggerBuzzer() {
        fetchData('/buzzer', { method: 'POST' });
    }

    function updateStatusLights(status) {
        for (const key in statusLights) {
            const light = statusLights[key];
            if (status[key]) {
                light.className = 'status-light ok';
            } else {
                light.className = 'status-light fail';
            }
        }
    }

    function updateLiveData(data) {
        dataFields.distance1.textContent = `${data.distance} cm`;
        dataFields.distance2.textContent = `${data.distance} cm`;
        if (data.color) dataFields.color.textContent = data.color;
        dataFields.ambient_temp1.textContent = `${data.ambient_temp} °C`;
        dataFields.ambient_temp2.textContent = `${data.ambient_temp} °C`;
        dataFields.object_temp.textContent = `${data.object_temp} °C`;
        dataFields.ultrasonic_speed1.textContent = `${data.ultrasonic_speed} m/s`;
        dataFields.ultrasonic_speed2.textContent = `${data.ultrasonic_speed} m/s`;
        if (data.absorption) dataFields.absorption.textContent = data.absorption;
    }

    function updateChart(newData) {
        distanceChart.data.labels = newData.map(d => d.reading);
        distanceChart.data.datasets[0].data = newData.map(d => d.distance);
        distanceChart.update();
    }
    
    // --- Event Listeners ---

    buttons.measureDistance.addEventListener('click', async () => {
        triggerBuzzer();
        const data = await fetchData('/measure_distance');
        if (data) updateLiveData(data);
    });

    buttons.detectShape.addEventListener('click', async () => {
        triggerBuzzer();
        const data = await fetchData('/detect_shape', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ repetitions: 15 })
        });
        if (data) {
            updateChart(data.shape_data);
            // Update live data with the last reading from the shape detection
            const lastReading = data.shape_data[data.shape_data.length - 1];
            const fullData = await fetchData('/measure_distance'); // get temp and other data
            if(fullData) {
                fullData.distance = lastReading.distance;
                updateLiveData(fullData);
            }
        }
    });

    buttons.testMaterial.addEventListener('click', async () => {
        triggerBuzzer();
        const data = await fetchData('/test_material');
        if (data) updateLiveData(data);
    });


    // --- Periodic Status Update ---
    
    async function refreshStatus() {
        const status = await fetchData('/status');
        if (status) {
            updateStatusLights(status);
            // Also update temperatures which are part of the status poll
            dataFields.ambient_temp1.textContent = `${status.ambient_temp} °C`;
            dataFields.ambient_temp2.textContent = `${status.ambient_temp} °C`;
            dataFields.object_temp.textContent = `${status.object_temp} °C`;
        }
    }

    setInterval(refreshStatus, 2000); // Refresh status every 2 seconds
    refreshStatus(); // Initial call
});