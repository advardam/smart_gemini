# app.py

from flask import Flask, jsonify, render_template, request
from hw_layer import (measure_distance, analyze_absorption, read_color,
                      read_temperature, buzzer_beep, read_button)
import threading
import json

app = Flask(__name__)

# GPIO pin config (for simulation context)
TRIG = 23
ECHO = 24
BUZZER = 18
BUTTON = 17

# --- API Endpoints ---

@app.route('/')
def index():
    """Serves the main dashboard page."""
    return render_template('index.html')

@app.route('/status')
def get_status():
    """Provides the status of all sensors."""
    temps = read_temperature()
    status = {
        "ultrasonic": random.choice([True, False]),
        "color_sensor": True,
        "temperature_sensor": True,
        "button": read_button(BUTTON),
        "oled_display": True,
        "buzzer": random.choice([True, False]),
        "ambient_temp": temps["ambient"],
        "object_temp": temps["object"],
    }
    return jsonify(status)

@app.route('/measure_distance')
def measure_distance_route():
    """Endpoint for a single distance measurement."""
    avg, sigma = measure_distance(TRIG, ECHO, samples=10)
    absorption = analyze_absorption(sigma)
    temps = read_temperature()
    # Speed of sound c ≈ 331.3 + 0.606 * T_ambient
    ultrasonic_speed = round(331.3 + 0.606 * temps["ambient"], 1)

    return jsonify({
        "distance": avg,
        "sigma": sigma,
        "absorption": absorption,
        "ambient_temp": temps["ambient"],
        "object_temp": temps["object"],
        "ultrasonic_speed": ultrasonic_speed
    })

@app.route('/test_material')
def measure_material_route():
    """Endpoint for testing material (color + distance)."""
    color = read_color()
    avg, sigma = measure_distance(TRIG, ECHO, samples=10)
    absorption = analyze_absorption(sigma)
    temps = read_temperature()
    ultrasonic_speed = round(331.3 + 0.606 * temps["ambient"], 1)

    return jsonify({
        "color": color["color_name"],
        "distance": avg,
        "sigma": sigma,
        "absorption": absorption,
        "ambient_temp": temps["ambient"],
        "object_temp": temps["object"],
        "ultrasonic_speed": ultrasonic_speed
    })

@app.route('/detect_shape', methods=['POST'])
def detect_shape_route():
    """Endpoint for detecting shape by taking multiple readings."""
    data = request.get_json()
    repetitions = data.get('repetitions', 15)
    measurements = []
    for i in range(repetitions):
        avg, _ = measure_distance(TRIG, ECHO, samples=10)
        measurements.append({"reading": i + 1, "distance": avg})
    return jsonify({"shape_data": measurements})

@app.route('/buzzer', methods=['POST'])
def buzz_route():
    """Endpoint to trigger the buzzer."""
    # Run in a thread to not block the request
    threading.Thread(target=buzzer_beep, args=(BUZZER, 0.1)).start()
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)