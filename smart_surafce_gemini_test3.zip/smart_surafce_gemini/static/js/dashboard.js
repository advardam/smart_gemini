// static/js/dashboard.js

document.addEventListener('DOMContentLoaded', function() {
    // --- DOM Elements ---
    const radarText = document.getElementById('radar-text-overlay');
    const buttons = {
        checkDistance: document.getElementById('btn-check-distance'),
        checkShape: document.getElementById('btn-check-shape'),
        checkMaterial: document.getElementById('btn-check-material'),
    };
    const allButtons = Object.values(buttons);
    const analysisFields = {
        shape: document.getElementById('analysis-shape'),
        material: document.getElementById('analysis-material'),
        avg: document.getElementById('stat-avg'),
        sigma: document.getElementById('stat-sigma'),
    };
    const modal = document.getElementById('conclusion-modal');
    const conclusionBtn = document.getElementById('btn-show-conclusion');
    const closeModalBtn = document.querySelector('.modal-close-button');
    // ... (Chart.js setup remains the same)

    // --- UI Control ---
    function setButtonsLoading(isLoading, message = 'Scanning...') {
        allButtons.forEach(btn => {
            btn.disabled = isLoading;
            if (isLoading) {
                radarText.textContent = message;
                radarText.classList.add('visible');
            } else {
                radarText.classList.remove('visible');
            }
        });
    }

    // --- API & Data Handling ---
    async function performScan(endpoint, body) {
        setButtonsLoading(true);
        // ... (fetch logic with error handling remains the same)
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        setButtonsLoading(false);

        if (!response.ok) {
            // ... (error handling)
            return;
        }
        
        const data = await response.json();
        return data;
    }

    function updateDashboard(data) {
        // ... (update analysisFields, chart, etc.)
        analysisFields.avg.textContent = `${data.statistics.average} cm`;
        analysisFields.sigma.textContent = data.statistics.sigma;
        analysisFields.shape.textContent = data.shape_analysis;
        analysisFields.material.textContent = data.material_analysis;

        // Show result on radar
        radarText.textContent = `${data.shape_analysis} Detected`;
        radarText.classList.add('visible');
        setTimeout(() => radarText.classList.remove('visible'), 2500);

        // Update chart
        distanceChart.data.labels = data.scan_data.map(d => d.reading);
        distanceChart.data.datasets[0].data = data.scan_data.map(d => d.distance);
        distanceChart.update();
    }

    // --- Event Listeners ---
    buttons.checkDistance.addEventListener('click', async () => {
        setButtonsLoading(true, 'Measuring...');
        const data = await performScan('/measure_distance_single', {});
        setButtonsLoading(false);
        if (data) {
            analysisFields.avg.textContent = `${data.distance} cm`;
            analysisFields.sigma.textContent = data.sigma;
            analysisFields.shape.textContent = "N/A";
            analysisFields.material.textContent = "N/A";
            radarText.textContent = `Distance: ${data.distance} cm`;
            radarText.classList.add('visible');
            setTimeout(() => radarText.classList.remove('visible'), 2500);
        }
    });

    buttons.checkShape.addEventListener('click', async () => {
        const data = await performScan('/scan', { repetitions: 20 });
        if (data) updateDashboard(data);
    });

    buttons.checkMaterial.addEventListener('click', async () => {
        const data = await performScan('/scan', { repetitions: 20 });
        if (data) updateDashboard(data);
    });

    // Modal listeners
    conclusionBtn.addEventListener('click', () => modal.classList.remove('hidden'));
    closeModalBtn.addEventListener('click', () => modal.classList.add('hidden'));
    modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.add('hidden'); // Close if clicking on background
    });
    
    // Chart.js initialization...
    const ctx = document.getElementById('distanceChart').getContext('2d');
    const distanceChart = new Chart(ctx, { /* ... same config ... */ });
});