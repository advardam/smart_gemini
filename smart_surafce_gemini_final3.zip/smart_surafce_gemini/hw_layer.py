# hw_layer.py

import time
import statistics

# --- NEW: Import from the modern gpiozero library ---
from gpiozero import Buzzer, Button, DistanceSensor

# I2C libraries for sensors and display
import board
import busio
import adafruit_tcs34725
import adafruit_mlx90614

from luma.core.interface.serial import i2c
from luma.core.render import canvas
from luma.oled.device import ssd1306

# --- HARDWARE SETUP (gpiozero handles most setup automatically) ---

try:
    i2c_bus = busio.I2C(board.SCL, board.SDA)
except Exception as e:
    print(f"FATAL: Could not initialize I2C bus. Check connections. Error: {e}")
    i2c_bus = None

# --- SENSOR INITIALIZATION ---

try:
    mlx_sensor = adafruit_mlx90614.MLX90614(i2c_bus)
except Exception as e:
    print(f"Warning: Could not initialize Temperature Sensor. Using default values. Error: {e}")
    mlx_sensor = None

try:
    tcs_sensor = adafruit_tcs34725.TCS34725(i2c_bus)
except Exception as e:
    print(f"Warning: Could not initialize Color Sensor. Using default values. Error: {e}")
    tcs_sensor = None
    
try:
    oled_serial = i2c(port=1, address=0x3C)
    oled_device = ssd1306(oled_serial)
except Exception as e:
    print(f"Warning: Could not initialize OLED Display. Printing to console instead. Error: {e}")
    oled_device = None

# --- HELPER FUNCTIONS (No changes) ---
def get_color_name(rgb):
    r, g, b = rgb
    if r > 200 and g > 200 and b > 200: return "White"
    if r < 30 and g < 30 and b < 30: return "Black"
    if r > g and r > b: return "Red"
    if g > r and g > b: return "Green"
    if b > r and b > g: return "Blue"
    if r > 100 and g > 100 and b < 50: return "Yellow"
    return "Unknown"

# --- CORE HARDWARE FUNCTIONS (Rewritten for gpiozero) ---

def read_temperature():
    if mlx_sensor:
        try:
            return {
                "ambient": round(mlx_sensor.ambient_temperature, 1),
                "object": round(mlx_sensor.object_temperature, 1)
            }
        except (OSError, IOError) as e:
            print(f"Error reading temperature sensor: {e}")
            return {"ambient": 0, "object": 0}
    else:
        return {"ambient": 25.0, "object": 25.0}

def read_color():
    if tcs_sensor:
        try:
            return {"color_name": get_color_name(tcs_sensor.color_rgb_bytes)}
        except Exception as e:
            print(f"Error reading color sensor: {e}")
            return {"color_name": "Error"}
    else:
        return {"color_name": "N/A"}

def buzzer_beep(pin, duration):
    """Creates a beep using a gpiozero Buzzer object."""
    buzzer = Buzzer(pin)
    buzzer.on()
    time.sleep(duration)
    buzzer.off()

def read_button(pin):
    """Reads the state of a button using gpiozero (assumes pull-up)."""
    button = Button(pin, pull_up=True)
    # Returns False if pressed, True if not pressed
    return not button.is_pressed

def measure_distance(trig_pin, echo_pin, samples=10):
    """Measures distance using the gpiozero DistanceSensor class."""
    sensor = DistanceSensor(echo=echo_pin, trigger=trig_pin)
    readings = []
    
    for _ in range(samples):
        # .distance gives meters, so multiply by 100 for cm
        distance_cm = sensor.distance * 100
        if 2 < distance_cm < 400: # Filter out unrealistic readings
            readings.append(distance_cm)
        time.sleep(0.05) # Wait a bit between readings

    if not readings:
        return 0, 0
        
    avg_distance = round(statistics.mean(readings), 2)
    std_dev = round(statistics.stdev(readings) if len(readings) > 1 else 0, 2)
    
    return avg_distance, std_dev
    
def analyze_absorption(sigma):
    """CALIBRATE THESE VALUES based on your testing."""
    if sigma > 1.2: return "High"
    elif sigma > 0.5: return "Medium"
    else: return "Low"

def update_physical_oled(distance, shape, material):
    if oled_device:
        try:
            with canvas(oled_device) as draw:
                draw.text((0, 0), f"Dist: {distance}", fill="white")
                draw.text((0, 12), f"Shape: {shape}", fill="white")
                draw.text((0, 24), f"Mat: {material}", fill="white")
        except Exception as e:
            print(f"Error writing to OLED: {e}")
    else:
        # Fallback to console if OLED failed to initialize
        print("--- Sending to Physical OLED (simulated) ---")
        print(f"  Line 1: Dist: {distance}")
        print(f"  Line 2: Shape: {shape}")
        print(f"  Line 3: Mat: {material}")
        print("---------------------------------")