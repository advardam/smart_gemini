// static/js/dashboard.js

document.addEventListener('DOMContentLoaded', function() {
    // --- DOM Elements ---
    const radarDot = document.getElementById('radar-dot');
    // ... (other element references)
    const analysisFields = {
        shape: document.getElementById('analysis-shape'),
        material: document.getElementById('analysis-material'),
        avg: document.getElementById('stat-avg'),
        sigma: document.getElementById('stat-sigma'),
        color: document.getElementById('env-color'),
        colorSwatch: document.getElementById('color-swatch'),
        tempDiff: document.getElementById('env-temp-diff'),
        speed: document.getElementById('env-speed'),
    };
    const clearBtn = document.getElementById('btn-clear');
    // ... (rest of the element references)

    // Chart.js initialization...
    const ctx = document.getElementById('distanceChart').getContext('2d');
    const distanceChart = new Chart(ctx, { /* ... same config ... */ });
    
    // --- UI Control ---

    function clearDashboard() {
        // Reset analysis text
        Object.values(analysisFields).forEach(el => {
            if (el.id.includes('color-swatch')) {
                el.style.backgroundColor = '#555';
            } else {
                el.textContent = 'N/A';
            }
        });
        analysisFields.avg.textContent = '- cm';
        analysisFields.sigma.textContent = '-';
        analysisFields.tempDiff.textContent = '- °C';
        analysisFields.speed.textContent = '- m/s';
        
        // Hide radar elements
        radarDot.classList.remove('visible');
        
        // Clear chart
        distanceChart.data.labels = [];
        distanceChart.data.datasets[0].data = [];
        distanceChart.update();
    }

    function setScanningState(isScanning, message = 'Scanning...') {
        if (isScanning) {
            clearDashboard(); // Clear old results when a new scan starts
            // ... (rest of the scanning state logic)
        }
        // ... (rest of the function)
    }
    
    // ... (performScan function remains the same)

    function updateDashboard(data) {
        triggerRadarPing();

        setTimeout(() => {
            // Update analysis card with main results
            analysisFields.avg.textContent = `${data.statistics.average} cm`;
            analysisFields.sigma.textContent = data.statistics.sigma;
            analysisFields.shape.textContent = data.shape_analysis;
            analysisFields.material.textContent = data.material_analysis;

            // Update with NEW environmental data
            const env = data.environment;
            analysisFields.color.textContent = env.color;
            analysisFields.colorSwatch.style.backgroundColor = env.color.toLowerCase();
            analysisFields.tempDiff.textContent = `${env.temp_difference} °C`;
            analysisFields.speed.textContent = `${env.ultrasonic_speed} m/s`;
            
            // Show radar dot
            radarDot.classList.add('visible');

            // ... (rest of the updateDashboard function)
            // ... (plotting the chart was already here and is correct)
            distanceChart.data.labels = data.scan_data.map(d => d.reading);
            distanceChart.data.datasets[0].data = data.scan_data.map(d => d.distance);
            distanceChart.update();
            
            setScanningState(false);
        }, 300);
    }
    
    // --- Event Listeners ---
    // ... (button listeners for scans remain the same)
    
    // NEW: Clear button listener
    clearBtn.addEventListener('click', clearDashboard);
    
    // Initial clear
    clearDashboard();
});