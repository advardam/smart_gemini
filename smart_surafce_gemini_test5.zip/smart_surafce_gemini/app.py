# app.py

from flask import Flask, jsonify, render_template, request
from hw_layer import (measure_distance, analyze_absorption, read_color,
                      read_temperature, buzzer_beep, update_physical_oled) 
import threading
import statistics
import random

app = Flask(__name__)

TRIG = 23
ECHO = 24
BUZZER = 18

def analyze_shape(sigma):
    if sigma < 0.5: return "Flat Surface"
    elif sigma < 2.5: return "Slightly Curved"
    else: return "Curved / Irregular"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/scan', methods=['POST'])
def scan_route():
    if random.random() < 0.1:
        return jsonify({"error": "Ultrasonic sensor timeout"}), 500

    data = request.get_json()
    repetitions = data.get('repetitions', 20)
    repetitions = min(int(repetitions), 100)
    
    distances = [measure_distance(TRIG, ECHO, samples=5)[0] for _ in range(repetitions)]
    scan_data = [{"reading": i + 1, "distance": dist} for i, dist in enumerate(distances)]
    
    # --- UPDATED: All calculations now happen here ---
    overall_sigma = round(statistics.stdev(distances), 2) if len(distances) > 1 else 0
    avg_distance = round(statistics.mean(distances), 2)

    # Analysis
    absorption_result = analyze_absorption(overall_sigma)
    material_type = "Absorbing" if absorption_result == "High" else "Reflective"
    shape_result = analyze_shape(overall_sigma)
    
    # NEW: Get environmental data
    temps = read_temperature()
    color = read_color()
    temp_diff = round(temps["object"] - temps["ambient"], 1)
    ultrasonic_speed = round(331.3 + 0.606 * temps["ambient"], 1)

    # Send primary results to physical OLED
    threading.Thread(
        target=update_physical_oled, 
        args=(f"{avg_distance} cm", shape_result, material_type)
    ).start()

    return jsonify({
        "scan_data": scan_data,
        "statistics": { "average": avg_distance, "sigma": overall_sigma },
        "shape_analysis": shape_result,
        "material_analysis": material_type,
        "environment": {
            "color": color["color_name"],
            "temp_difference": temp_diff,
            "ultrasonic_speed": ultrasonic_speed
        }
    })
    
@app.route('/measure_distance_single', methods=['POST'])
def measure_distance_single_route():
    avg, sigma = measure_distance(TRIG, ECHO, samples=10)
    threading.Thread(
        target=update_physical_oled, 
        args=(f"{avg} cm", "N/A", "N/A")
    ).start()
    return jsonify({ "distance": avg, "sigma": sigma })

@app.route('/buzzer', methods=['POST'])
def buzz_route():
    threading.Thread(target=buzzer_beep, args=(BUZZER, 0.05)).start()
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)