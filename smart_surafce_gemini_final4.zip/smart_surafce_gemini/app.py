# app.py

from flask import Flask, jsonify, render_template, request
from hw_layer import (measure_distance, analyze_absorption, read_color,
                      read_temperature, buzzer_beep, update_physical_oled) 
import threading
import statistics
import random

app = Flask(__name__)

# Pin numbers are now only needed for components created on-the-fly, like the buzzer.
# The DistanceSensor pins are handled inside hw_layer.py.
BUZZER_PIN = 18

def analyze_shape(sigma):
    if sigma < 0.5: return "Flat Surface"
    elif sigma < 2.5: return "Slightly Curved"
    else: return "Curved / Irregular"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/scan', methods=['POST'])
def scan_route():
    if random.random() < 0.1:
        return jsonify({"error": "Ultrasonic sensor timeout"}), 500

    data = request.get_json()
    repetitions = data.get('repetitions', 20)
    repetitions = min(int(repetitions), 100)
    
    # --- UPDATED: Call measure_distance without pin arguments ---
    distances = [measure_distance(samples=5)[0] for _ in range(repetitions)]
    scan_data = [{"reading": i + 1, "distance": dist} for i, dist in enumerate(distances)]
    
    if not distances:
        return jsonify({"error": "Failed to get any valid distance readings."}), 500

    overall_sigma = round(statistics.stdev(distances), 2) if len(distances) > 1 else 0
    avg_distance = round(statistics.mean(distances), 2)

    absorption_result = analyze_absorption(overall_sigma)
    material_type = "Absorbing" if absorption_result == "High" else "Reflective"
    shape_result = analyze_shape(overall_sigma)
    
    temps = read_temperature()
    color = read_color()
    temp_diff = round(temps["object"] - temps["ambient"], 1)
    ultrasonic_speed = round(331.3 + 0.606 * temps["ambient"], 1)

    threading.Thread(
        target=update_physical_oled, 
        args=(f"{avg_distance} cm", shape_result, material_type)
    ).start()

    return jsonify({
        "scan_data": scan_data,
        "statistics": { "average": avg_distance, "sigma": overall_sigma },
        "shape_analysis": shape_result,
        "material_analysis": material_type,
        "environment": {
            "color": color["color_name"],
            "temp_difference": temp_diff,
            "ultrasonic_speed": ultrasonic_speed
        }
    })
    
@app.route('/measure_distance_single', methods=['POST'])
def measure_distance_single_route():
    # --- UPDATED: Call measure_distance without pin arguments ---
    avg, sigma = measure_distance(samples=10)
    threading.Thread(
        target=update_physical_oled, 
        args=(f"{avg} cm", "N/A", "N/A")
    ).start()
    return jsonify({ "distance": avg, "sigma": sigma })

@app.route('/buzzer', methods=['POST'])
def buzz_route():
    threading.Thread(target=buzzer_beep, args=(BUZZER_PIN, 0.05)).start()
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)```

