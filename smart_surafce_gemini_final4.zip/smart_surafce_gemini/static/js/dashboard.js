// static/js/dashboard.js

document.addEventListener('DOMContentLoaded', function() {
    // --- DOM Elements ---
    const radar = document.getElementById('radar');
    const radarText = document.getElementById('radar-text-overlay');
    const radarDot = document.getElementById('radar-dot');

    const buttons = {
        checkDistance: document.getElementById('btn-check-distance'),
        checkShape: document.getElementById('btn-check-shape'),
        checkMaterial: document.getElementById('btn-check-material'),
    };
    const allButtons = Object.values(buttons);

    const analysisFields = {
        shape: document.getElementById('analysis-shape'),
        material: document.getElementById('analysis-material'),
        avg: document.getElementById('stat-avg'),
        sigma: document.getElementById('stat-sigma'),
        color: document.getElementById('env-color'),
        colorSwatch: document.getElementById('color-swatch'),
        tempDiff: document.getElementById('env-temp-diff'),
        speed: document.getElementById('env-speed'),
    };

    const modal = document.getElementById('conclusion-modal');
    const conclusionBtn = document.getElementById('btn-show-conclusion');
    const closeModalBtn = document.querySelector('.modal-close-button');
    const clearBtn = document.getElementById('btn-clear');

    // Chart.js initialization
    const ctx = document.getElementById('distanceChart').getContext('2d');
    const distanceChart = new Chart(ctx, {
        type: 'line',
        data: { labels: [], datasets: [{
            label: 'Distance (cm)', data: [],
            borderColor: 'rgba(243, 196, 62, 1)',
            backgroundColor: 'rgba(243, 196, 62, 0.2)',
            borderWidth: 2, tension: 0.1, fill: true
        }]},
        options: {
            scales: {
                y: { beginAtZero: true, title: { display: true, text: 'Distance (cm)', color: '#fff' }, ticks: { color: '#fff' } },
                x: { title: { display: true, text: 'Reading #', color: '#fff' }, ticks: { color: '#fff' } }
            },
            plugins: { legend: { display: false } }
        }
    });

    // --- UI Control ---

    function clearDashboard() {
        Object.values(analysisFields).forEach(el => {
            if (el.id.includes('color-swatch')) {
                el.style.backgroundColor = '#555';
            } else {
                el.textContent = 'N/A';
            }
        });
        analysisFields.avg.textContent = '- cm';
        analysisFields.sigma.textContent = '-';
        analysisFields.tempDiff.textContent = '- °C';
        analysisFields.speed.textContent = '- m/s';
        
        radarDot.classList.remove('visible');
        
        distanceChart.data.labels = [];
        distanceChart.data.datasets[0].data = [];
        distanceChart.update();
    }

    function setScanningState(isScanning, message = 'Scanning...') {
        allButtons.forEach(btn => { btn.disabled = isScanning; });

        if (isScanning) {
            clearDashboard();
            radar.classList.add('is-scanning');
            radarText.textContent = message;
            radarText.classList.add('visible');
        } else {
            radar.classList.remove('is-scanning');
        }
    }

    function triggerRadarPing() {
        radar.classList.add('is-pinging');
        setTimeout(() => radar.classList.remove('is-pinging'), 700);
    }

    // --- API & Data Handling ---

    async function performScan(endpoint, body) {
        setScanningState(true);
        try {
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });
            if (!response.ok) {
                // Handle errors if needed
                setScanningState(false);
                return null;
            }
            return await response.json();
        } catch (error) {
            console.error("Scan failed:", error);
            setScanningState(false);
            return null;
        }
    }

    function updateDashboard(data) {
        triggerRadarPing();

        setTimeout(() => {
            // Update Analysis Card
            analysisFields.avg.textContent = `${data.statistics.average} cm`;
            analysisFields.sigma.textContent = data.statistics.sigma;
            analysisFields.shape.textContent = data.shape_analysis;
            analysisFields.material.textContent = data.material_analysis;
            
            const env = data.environment;
            analysisFields.color.textContent = env.color;
            analysisFields.colorSwatch.style.backgroundColor = env.color.toLowerCase();
            analysisFields.tempDiff.textContent = `${env.temp_difference} °C`;
            analysisFields.speed.textContent = `${env.ultrasonic_speed} m/s`;
            
            radarDot.classList.add('visible');

            // Show result text on radar
            radarText.textContent = `${data.shape_analysis} Detected`;
            setTimeout(() => radarText.classList.remove('visible'), 2500);

            // Plot data on chart
            distanceChart.data.labels = data.scan_data.map(d => d.reading);
            distanceChart.data.datasets[0].data = data.scan_data.map(d => d.distance);
            distanceChart.update();

            setScanningState(false);
        }, 300);
    }

    // --- Event Listeners ---
    buttons.checkDistance.addEventListener('click', async () => {
        const data = await performScan('/measure_distance_single', {});
        if (data) {
            triggerRadarPing();
            setTimeout(() => {
                clearDashboard();
                analysisFields.avg.textContent = `${data.distance} cm`;
                analysisFields.sigma.textContent = data.sigma;
                radarDot.classList.add('visible');
                
                radarText.textContent = `Distance: ${data.distance} cm`;
                setTimeout(() => radarText.classList.remove('visible'), 2500);

                setScanningState(false);
            }, 300);
        }
    });

    buttons.checkShape.addEventListener('click', async () => {
        const data = await performScan('/scan', { repetitions: 20 });
        if (data) updateDashboard(data);
    });

    buttons.checkMaterial.addEventListener('click', async () => {
        const data = await performScan('/scan', { repetitions: 20 });
        if (data) updateDashboard(data);
    });

    // Modal and Clear listeners
    conclusionBtn.addEventListener('click', () => modal.classList.remove('hidden'));
    closeModalBtn.addEventListener('click', () => modal.classList.add('hidden'));
    modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.add('hidden');
    });
    clearBtn.addEventListener('click', clearDashboard);
    
    // Initial clear
    clearDashboard();
});