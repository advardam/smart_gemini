# hw_layer.py

import time
import statistics
from gpiozero import Buzzer, Button, DistanceSensor

# I2C libraries
import board
import busio
import adafruit_tcs34725
import adafruit_mlx90614

# Luma OLED libraries
from luma.core.interface.serial import i2c
from luma.core.render import canvas
from luma.oled.device import ssd1306

# --- ONE-TIME HARDWARE SETUP ---

try:
    i2c_bus = busio.I2C(board.SCL, board.SDA)
except Exception as e:
    print(f"FATAL: I2C bus could not be initialized. Error: {e}")
    i2c_bus = None

# --- SENSOR AND DEVICE INITIALIZATION ---

# Initialize I2C Sensors
mlx_sensor = adafruit_mlx90614.MLX90614(i2c_bus) if i2c_bus else None
tcs_sensor = adafruit_tcs34725.TCS34725(i2c_bus) if i2c_bus else None

# Initialize OLED Display
try:
    oled_serial = i2c(port=1, address=0x3C)
    oled_device = ssd1306(oled_serial)
except Exception as e:
    print(f"Warning: Could not initialize OLED Display. Printing to console instead. Error: {e}")
    oled_device = None

# --- NEW: Initialize the Distance Sensor ONCE, globally ---
try:
    # We get the pin numbers from the main app.py file
    # For now, define them here. They will be passed from the app.
    distance_sensor_obj = DistanceSensor(echo=24, trigger=23)
except Exception as e:
    print(f"Warning: Could not initialize Distance Sensor. Error: {e}")
    distance_sensor_obj = None

# ... (Helper functions like get_color_name are unchanged) ...
def get_color_name(rgb):
    r, g, b = rgb
    if r > 200 and g > 200 and b > 200: return "White"
    if r < 30 and g < 30 and b < 30: return "Black"
    if r > g and r > b: return "Red"
    if g > r and g > b: return "Green"
    if b > r and b > g: return "Blue"
    if r > 100 and g > 100 and b < 50: return "Yellow"
    return "Unknown"

# --- CORE HARDWARE FUNCTIONS (measure_distance is now simplified) ---
# ... (read_temperature, read_color, buzzer_beep, read_button are unchanged) ...
def read_temperature():
    if mlx_sensor:
        try:
            return {"ambient": round(mlx_sensor.ambient_temperature, 1), "object": round(mlx_sensor.object_temperature, 1)}
        except (OSError, IOError): return {"ambient": 0, "object": 0}
    return {"ambient": 25.0, "object": 25.0}

def read_color():
    if tcs_sensor:
        try: return {"color_name": get_color_name(tcs_sensor.color_rgb_bytes)}
        except Exception: return {"color_name": "Error"}
    return {"color_name": "N/A"}

def buzzer_beep(pin, duration):
    Buzzer(pin).beep(on_time=duration, n=1)

def read_button(pin):
    return not Button(pin, pull_up=True).is_pressed

def measure_distance(samples=10):
    """
    Measures distance using the pre-initialized global DistanceSensor object.
    The trig_pin and echo_pin arguments are no longer needed.
    """
    if not distance_sensor_obj:
        print("Distance sensor is not available.")
        return 0, 0
        
    readings = []
    for _ in range(samples):
        distance_cm = distance_sensor_obj.distance * 100
        if 2 < distance_cm < 400:
            readings.append(distance_cm)
        time.sleep(0.06) # Slightly longer sleep for stability

    if not readings:
        return 0, 0
        
    avg_distance = round(statistics.mean(readings), 2)
    std_dev = round(statistics.stdev(readings) if len(readings) > 1 else 0, 2)
    
    return avg_distance, std_dev

# ... (analyze_absorption and update_physical_oled are unchanged) ...
def analyze_absorption(sigma):
    if sigma > 1.2: return "High"
    elif sigma > 0.5: return "Medium"
    else: return "Low"

def update_physical_oled(distance, shape, material):
    if oled_device:
        try:
            with canvas(oled_device) as draw:
                draw.text((0, 0), f"Dist: {distance}", fill="white")
                draw.text((0, 12), f"Shape: {shape}", fill="white")
                draw.text((0, 24), f"Mat: {material}", fill="white")
        except Exception as e: print(f"Error writing to OLED: {e}")
    else:
        print(f"--- OLED Sim ---\nDist: {distance}\nShape: {shape}\nMat: {material}\n----------------")